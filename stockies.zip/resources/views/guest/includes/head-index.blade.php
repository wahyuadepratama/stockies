<!-- Fonts -->
<link href="https://fonts.googleapis.com/css?family=Asap" rel="stylesheet">

<link href="https://fonts.googleapis.com/css?family=Istok+Web" rel="stylesheet">

<!-- Animate.css -->
<link rel="stylesheet" href="{{URL::asset('user-panel/css/animate.css')}}">
<!-- Icomoon Icon Fonts-->
<link rel="stylesheet" href="{{URL::asset('user-panel/css/icomoon.css')}}">
<!-- Bootstrap  -->
<link rel="stylesheet" href="{{URL::asset('user-panel/css/bootstrap.css')}}">

<!-- Flexslider  -->
<link rel="stylesheet" href="{{URL::asset('user-panel/css/flexslider.css')}}">

<!-- Owl Carousel  -->
<link rel="stylesheet" href="{{URL::asset('user-panel/css/owl.carousel.min.css')}}">
<link rel="stylesheet" href="{{URL::asset('user-panel/css/owl.theme.default.min.css')}}">

<!-- Theme style  -->
<link rel="stylesheet" href="{{URL::asset('user-panel/css/style.css')}}">

<!-- Modernizr JS -->
<script src="{{URL::asset('user-panel/js/modernizr-2.6.2.min.js')}}"></script>
<!-- FOR IE9 below -->
<!--[if lt IE 9]>
<script src="js/respond.min.js"></script>
<![endif]-->
<!-- <link href="https://fonts.googleapis.com/css?family=Montserrat:400,700" rel="stylesheet"> -->
<!-- <link href="https://fonts.googleapis.com/css?family=Playfair+Display:400,400i" rel="stylesheet"> -->
