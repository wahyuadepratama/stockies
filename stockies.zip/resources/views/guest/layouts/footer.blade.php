<footer id="fh5co-footer" role="contentinfo">
  <div class="container" style="padding-top: 5%;">
    <div class="row row-pb-md" >
      <div class="col-md-12 fh5co-widget"  >
        <div class="text-center">
        <h3 >Ingin tau lebih lanjut tentang Stockies ?</h3>
        </div>
      </div>
    </div>

    <div class="tentang">

      <div class="col-sm-4">

      </div>
      <div class="col-md-2 account  tentangkami">
        <p><a href="/about"><img src="{{asset('storage/images/ic_account_circle_24px.png')}}">Tentang Kami</a></p>
      </div>
      <div class="col-md-2 account">
        <p><a href="/faq"><img src="{{asset('storage/images/ic_account_circle_24px.png')}}">FAQ</a></p>
      </div>

    </div>


    <div class="row copyright">
      <div class="col-md-12 text-center">
        <p>
          <!-- <small class="block">&copy; 2018 Free HTML5. All Rights Reserved.</small>
          <small class="block">Designed by <a href="http://freehtml5.co/" target="_blank">FreeHTML5.co</a> Demo Images: <a href="http://blog.gessato.com/" target="_blank">Gessato</a> &amp; <a href="http://unsplash.co/" target="_blank">Unsplash</a></small> -->


          <small><a href="" target="">Hubungi Kami</a></small>
        </p>
        <p>
          <ul class="fh5co-social-icons">

            <li><a href="#"><i class="icon-facebook"></i><small>Stockies</small></a></li>
            <li><a href="#"><i class="icon-instagram"></i><small>@Stockies</small></a></li>
            <li><a href="#"><i class="icon-twitter"></i><small>@Stockies</small></a></li>

          </ul>
        </p>
      </div>
    </div>

  </div>
</footer>
