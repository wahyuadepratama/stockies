@extends('guest.master')

@section('content')

  <div id="fh5co-about">
    <div class="container">
      <div class="about-content">
        <div class="row animate-box">
          <div class="col-md-7">
            <div class="tentang-kami">
              <h3 style="">Tentang Kami</h3>

              <p><b>Stockies</b> adalah situs E-Commerce yang menyediakan foto-foto mengenai kearifan lokal yang ada di Indonesia.</p>

              <p>Stockies menyediakan foto-foto dengan kualitas yang tinggi dan memiliki variasi yang banyak yang dapat digunakan untuk semua orang ataupun setiap perusahaan yang memerlukan foto mengenai kearifan lokal Indonesia. </p>

              <p>Setiap foto disusun secara rapi dan mudah untuk ditemukan di dalam situs kami. Setiap foto yang ada dilisensi dengan lisensi Stockies, sehingga mengamankan para pemilik foto dalam penjualan fotonya. </p>
            </div>

          </div>

        </div>
      </div>
    </div>
  </div>

@endsection
