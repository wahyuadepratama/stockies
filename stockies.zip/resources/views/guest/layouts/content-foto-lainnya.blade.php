<div class="col-md-2"></div>
<div class="col-md-2"></div>
<div class="col-md-1"></div>
<a href="/gallery">
  <div class="col-md-2 button" style="margin-bottom: 30px; margin-top: 30px;">
      <p>Telusuri Foto Lainnya</p>
  </div>
</a>
